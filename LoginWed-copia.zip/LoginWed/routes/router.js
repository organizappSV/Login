const express = require('express')
const router = express.Router();
const authController = require('../controllers/authController')

//routes para las vistas
router.get('/', authController.isAutenticated, (req,res) => {
    res.render('index', {email:req.email});
})
router.get('/login', (req,res) => {
    res.render('login', {alert:false});
})

router.get('/register', (req,res) => {
    res.render('register');
})
//Home
router.get('/Perfil',  authController.isAutenticated,(req,res) => {
    res.render('Perfil',{email:req.email});
})
router.get('/Calendario', authController.isAutenticated, (req,res) => {
    res.render('Calendario', {email:req.email});
})

router.get('/Notificaciones', authController.isAutenticated, (req,res) => {
    res.render('Notificaciones', {email:req.email});
})


//Sub rutas Home
router.get('/Agenda', (req,res)=>{
    res.render('Agenda', );
})
router.get('/Pagos', (req,res)=>{
    res.render('Pagos');
})
router.get('/Ahorros-y-Metas', (req,res)=>{
    res.render('Ahorros-y-Metas');
})
router.get('/Ingresos-y-Gastos', (req,res)=>{
    res.render('Ingresos-y-Gastos');
})
//routes para los metodos del controller
router.post('/register', authController.register)
router.post('/login', authController.login)
router.get('/logout', authController.logout)

//primas home rutas
router.post('/Perfil', authController.login)
router.post('/Calendario', authController.login)
router.post('/Notificaciones', authController.login)



//Sub routes para metodos del controoler
router.post('/Agenda', authController.Agenda)
router.post('/Pagos', authController.Pagos)
router.post('/Ahorros-y-Metas', authController.Ahorros)
router.post('/Ingresos-y-Gastos', authController.Ingresos)
module.exports=  router;