const jwt = require('jsonwebtoken')
const bcryptjs = require('bcryptjs')
const  conexion = require('../database/db')
const {promisify} = require('util')
const { error } = require('console')
const { ifError } = require('assert')

//procediiento para registranos

exports.register = async(req, res)=>{
    try {
        const Nombre = req.body.Nombre
        const  email= req.body.email
        const password = req.body.password
        let passwordHaash = await bcryptjs.hash(password, 8);
        const Fecha = req.body.Fecha
   
        //console.log(passwordHash)
        conexion.query('INSERT INTO registro SET ?',{Nombre:Nombre, email:email, password:passwordHaash, Fecha:Fecha},(error, results)=>{
            if(error){console.log(error)}
             res.redirect('/');
        })
    } catch (error) {
        console.log(error)
        
    }


}

exports.login = async(req, res)=>{
    try { 
        const  email = req.body.email
        const password = req.body.password 

        if (!email || !password) {
            res.render('login',{
                alert:true,
                alertTitle: "Advertencias",
                alertMessage:"Ingrese su Correo Electronico y contraseña",
                alertIcon:'Info',
                showConfirmButton: true,
                timer: false,
                ruta: 'login'
            })
        }else{
            conexion.query('SELECT * FROM registro WHERE email = ?', [email], async (error, results)=>{
                if( results.length == 0 || ! (await bcryptjs.compare(password, results[0].password)) ){
                    res.render('login', {
                        alert: true,
                        alertTitle: "Error",
                        alertMessage: "Usuario y/o Password incorrectas",
                        alertIcon:'error',
                        showConfirmButton: true,
                        timer: 1200,
                        ruta: 'login'   
                    })
                }else{
                    //inicio de session bueno
                    const Id = results[0].Id
                    const token = jwt.sign({Id:Id}, process.env.JWT_SECRETO,{
                        expiresIn : process.env.JWT_TIEMPO_EXPIRA
                    })
                    console.log("token:" +token+"para el usuario : " + email)

                    const cookiesOptions ={
                        expires: new Date(Date.now()+process.env.JWT_COOKIE_EXPIRES * 24 * 60 * 60 * 1000),
                        httpOnly: true
                    }
                    res.cookie('jwt', token, cookiesOptions)
                    res.render('login',{
                        alert:true,
                        alertTitle: "Exito!",
                        alertMessage:`Bienvenido a OrganizaApp`,
                        alertIcon:'Success',
                        showConfirmButton: false,
                        timer:5000,
                        ruta: ''
                    })
                }
            })
        }
        
    } catch (error) {
        console.log(error)
    }
}

exports.isAutenticated = async(req, res, next)=>{
    if(req.cookies.jwt){
        try {
            const decodificada = await promisify(jwt.verify)(req.cookies.jwt, process.env.JWT_SECRETO)
            conexion.query('SELECT * FROM registro WHERE Id = ? ', [decodificada.Id], (error, results)=>{
                if(!results){return next()}
                req.email = results[0]
                return next()
            })
        } catch (error){
            console.log(error)
            return next()
        }
    }else{
        res.redirect('/login')       

    }
}

exports.logout = (req, res)=>{
    res.clearCookie('jwt')   
    return res.redirect('/')
}

exports.Agenda = (req, res)=>{
    res.send("Agenda")
}

exports.Pagos = (req, res)=>{
    res.send("pagos")
}

exports.Ahorros = (req, res)=>{
    res.send("Ahorros-y-Metas")
}

exports.Ingresos = (req, res)=>{
    res.send("Ingresos-y-Metas")
}